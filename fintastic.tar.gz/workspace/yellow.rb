def yellowpager (word)
    if word.length != 10 
        false
    end
    word.split('').each do |letter|
        if letter.ord > 121 
            # letter = "z"
            puts letter.to_s + " = " + ((letter.ord-3)/3-30).to_s
        elsif letter.ord > 114 
            # letter is "s" or higher
            puts letter.to_s + " = " + ((letter.ord-2)/3-30).to_s
        else
            # for other letters (ASCII code -1)/3-30  =  keypad code 
            puts letter.to_s + " = " + ((letter.ord-1)/3-30).to_s
        end
    end
end

yellowpager ("abcdefghijklmnopqrstuvwxyz")